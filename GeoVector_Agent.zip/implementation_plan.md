# Indexed Color Map Support Plan

You bring up a brilliant point! Many geological GIS rasters are saved as **Indexed Color (Paletted)** single-band `.tif` files to save disk space. Even though they look vividly colored in QGIS, the file technically only has `count=1` band, which causes our Python script to mistakenly assume it's purely black & white grayscale!

I will upgrade the code to dynamically unpack 1-band colormaps so they can be processed as full RGB.

## User Review Required
> [!IMPORTANT]
> Please review the logic I will add below. It specifically addresses the `count=1` colored map limitation you discovered.

## Proposed Changes

### 1. Indexed Colormap Extraction
When loading the raster with `rasterio`, I will add a check for `.colormap(1)`. 
- **Change:** If the image is `count=1` but contains an embedded GIS palette (Colormap), the script will instantly unpack the index values and reconstruct a rich `(H, W, 3)` RGB tensor array in memory.
- It will then trigger the *"This map appears to be colored..."* prompt so you can train the AI on the true colors.

### 2. Fallback Safety
- **Change:** If the image is `count=1` and genuinely has *no* colormap (a pure grayscale scan), it will bypass the prompt as before and default safely to 1-channel grayscale deep learning.

### 3. ZIP Re-Packaging
- I will execute the packaging script again to slip this extremely robust colormap logic into the `geovector_unet_os.py` inside your `GeoVector_Agent.zip` archive so your team has flawless color support for all raster types.

## Open Questions
- Does this embedded Colormap extraction logic perfectly address the issue you are experiencing with your 1-band maps? 
